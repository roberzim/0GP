from __future__ import annotations

"""
db_core.py
----------------

Utility functions for working with the SQLite database used by the 0GP
application.  This module centralises creation of the database path,
opening connections with appropriate PRAGMA settings, initialising the
schema from ``db_schema.sql`` and providing a simple transaction context
manager.  It can be dropped into the root of the 0GP repository to
provide the minimum functionality required by the dual‑write layer.

The public API exposed here consists of:

``get_db_path()``
    Resolve the location of the primary SQLite database.  It honours the
    ``GP_DB_PATH`` environment variable when set, otherwise it defaults
    to ``archivio/gestione_pratiche.sqlite`` and ensures the parent
    directory exists.

``connect(db_path=None)``
    Open a connection to the specified database, returning rows as
    dictionaries via ``row_factory``.  SQLite PRAGMAs are set up to
    enable WAL mode, normal synchronous behaviour and foreign keys.

``init_db(db_path=None, schema_path='db_schema.sql')``
    Initialise the database if it does not already exist by executing
    the SQL contained in the schema file.  This function is idempotent
    thanks to ``CREATE TABLE IF NOT EXISTS`` statements.

``transaction(conn)``
    A context manager which wraps a ``BEGIN``/``COMMIT``/``ROLLBACK``
    sequence around a block of code.  It will roll back the transaction
    if any exception escapes the body.

This module does not depend on any third‑party libraries; only the
standard ``sqlite3`` module is required.
"""

import os
import sqlite3
from contextlib import contextmanager
from typing import Optional


def get_db_path() -> str:
    """Return the absolute path to the SQLite database file.

    If the ``GP_DB_PATH`` environment variable is set it will be used
    verbatim; otherwise the default path ``archivio/gestione_pratiche.sqlite``
    is returned.  The parent directory of the resulting path is created
    if it does not already exist.

    Returns
    -------
    str
        The path to the SQLite database file.
    """
    # Honour explicit environment override
    db_path = os.environ.get("GP_DB_PATH")
    if not db_path:
        db_path = os.path.join("archivio", "gestione_pratiche.sqlite")
    # Ensure the parent directory exists
    parent = os.path.dirname(db_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    return db_path


def connect(db_path: Optional[str] = None) -> sqlite3.Connection:
    """Open a new SQLite connection with sensible defaults.

    Parameters
    ----------
    db_path : str, optional
        Location of the SQLite database file.  When omitted the path
        returned by :func:`get_db_path` is used.

    Returns
    -------
    sqlite3.Connection
        A connection object configured for row access via mapping
        (``row_factory = sqlite3.Row``) and with WAL/synchronous/foreign
        key PRAGMAs enabled.
    """
    if db_path is None:
        db_path = get_db_path()
    # Guarantee parent directory exists
    parent = os.path.dirname(db_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    con = sqlite3.connect(db_path, detect_types=sqlite3.PARSE_DECLTYPES)
    con.row_factory = sqlite3.Row
    # Apply PRAGMAs to improve reliability and performance
    try:
        con.execute("PRAGMA journal_mode=WAL")
    except Exception:
        pass
    try:
        con.execute("PRAGMA synchronous=NORMAL")
    except Exception:
        pass
    try:
        con.execute("PRAGMA foreign_keys=ON")
    except Exception:
        pass
    return con


def init_db(db_path: Optional[str] = None, schema_path: str = "db_schema.sql") -> None:
    """Initialise the SQLite database by executing the supplied schema.

    This function reads the schema from ``schema_path`` and executes it
    against the database at ``db_path``.  It is safe to call this
    repeatedly; ``CREATE TABLE IF NOT EXISTS`` guards ensure tables
    will not be recreated if they already exist.

    Parameters
    ----------
    db_path : str, optional
        Location of the database file.  Defaults to the path returned by
        :func:`get_db_path`.
    schema_path : str, optional
        Path to the SQL file containing DDL statements.  Defaults to
        ``db_schema.sql`` in the repository root.
    """
    if db_path is None:
        db_path = get_db_path()
    if not os.path.exists(schema_path):
        raise FileNotFoundError(f"Schema file not found: {schema_path}")
    with open(schema_path, "r", encoding="utf-8") as f:
        schema_sql = f.read()
    # Use connect() here to apply PRAGMAs and row_factory
    with connect(db_path) as con:
        con.executescript(schema_sql)


@contextmanager
def transaction(conn: sqlite3.Connection):
    """Context manager to wrap a transaction on an existing connection.

    Begins a transaction with ``BEGIN`` on entry, yields the
    connection to the caller for the duration of the ``with`` block and
    automatically commits on successful exit.  If an exception is
    raised, a rollback is attempted before re‑raising the exception.

    Example
    -------

    .. code-block:: python

        with transaction(conn) as con:
            con.execute("INSERT INTO pratiche (...) VALUES (...)")
            # other operations...

    """
    try:
        conn.execute("BEGIN")
        yield conn
        conn.execute("COMMIT")
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except Exception:
            # ignore secondary errors during rollback
            pass
        raise