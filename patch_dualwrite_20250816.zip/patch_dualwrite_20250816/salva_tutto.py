from __future__ import annotations

"""
salva_tutto.py
----------------

An entry point for saving practice data used by the 0GP user interface.
This module historically handled writing both JSON and SQLite, but for
consistency the heavy lifting has been refactored into
``dual_save.save_all``.  The functions defined here now forward
requests to :func:`dual_save.save_all` and expose a thin wrapper
around the underlying persistence logic.

Functions
---------

salva_tutto(pratica, *, json_root="app_pratiche", db_path=None)
    Save a practice dictionary by delegating to ``dual_save.save_all``.
    Additional parameters are ignored for compatibility.

salva_pratica(pratica, *args, **kwargs)
    Alias to ``salva_tutto``; accepts and ignores extra positional and
    keyword arguments.

dump_to_json(data, path)
    Write a dictionary to a JSON file using an atomic write.  This is
    provided as a small utility for callers that need only JSON
    persistence.
"""

import os
import json
import tempfile
from pathlib import Path
from typing import Dict, Any, Optional

from dual_save import save_all


def _atomic_write_json(path: Path, data: Dict[str, Any]) -> None:
    """Write a JSON file to ``path`` atomically.

    Creates the parent directory if necessary, writes to a temporary
    file in the same directory and atomically replaces the target on
    completion.  ``fsync`` is used to reduce the risk of data loss on
    system crashes.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name, dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        try:
            os.remove(tmp)
        except FileNotFoundError:
            pass


def salva_tutto(pratica: Dict[str, Any], *, json_root: str = "app_pratiche", db_path: Optional[str] = None) -> Dict[str, str]:
    """Persist a practice by delegating to :func:`dual_save.save_all`.

    The ``json_root`` and ``db_path`` parameters are accepted for
    compatibility with previous versions but are ignored; the JSON
    location is derived from ``id_pratica`` and the database path is
    resolved via ``db_core.get_db_path``.  See ``dual_save.save_all``
    for details of the return structure.
    """
    return save_all(pratica)


def salva_pratica(pratica: Dict[str, Any], *args, **kwargs) -> Dict[str, str]:
    """Alias of :func:`salva_tutto` accepting arbitrary extra arguments.

    The UI may call this function with additional positional or
    keyword parameters.  They are ignored and the practice is saved
    using ``dual_save.save_all``.
    """
    return save_all(pratica)


def dump_to_json(data: Dict[str, Any], path: str) -> None:
    """Write data to a JSON file using an atomic write.

    Parameters
    ----------
    data : dict
        The data to serialise.
    path : str
        The filesystem path at which to write the JSON file.
    """
    p = Path(path)
    _atomic_write_json(p, data)