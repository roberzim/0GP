-- db_schema.sql
-- ----------------
--
-- Minimum viable database schema for the 0GP application.  This DDL
-- describes the tables required to store practices and their
-- associated deadlines and documents, as well as an id counter table
-- used to generate sequential identifiers per year.

PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS id_counter (
  anno INTEGER PRIMARY KEY,
  last_n INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS pratiche (
  id_pratica TEXT PRIMARY KEY,
  anno INTEGER,
  numero INTEGER,
  titolo TEXT,
  stato TEXT,
  created_at TEXT,
  updated_at TEXT,
  raw_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS scadenze (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  id_pratica TEXT NOT NULL REFERENCES pratiche(id_pratica) ON DELETE CASCADE,
  data TEXT,
  descrizione TEXT,
  stato TEXT
);

CREATE INDEX IF NOT EXISTS idx_scadenze_pratica ON scadenze(id_pratica);

CREATE TABLE IF NOT EXISTS documenti (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  id_pratica TEXT NOT NULL REFERENCES pratiche(id_pratica) ON DELETE CASCADE,
  nome TEXT,
  path TEXT,
  tipo TEXT
);

CREATE INDEX IF NOT EXISTS idx_documenti_pratica ON documenti(id_pratica);