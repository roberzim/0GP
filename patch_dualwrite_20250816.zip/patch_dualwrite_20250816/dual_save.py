from __future__ import annotations

"""
dual_save.py
----------------

This module orchestrates saving a practice both to JSON on disk and
into a SQLite database.  The primary entry point is
``save_all(data, json_path=None)`` which takes a dictionary
representing a practice and persists it to both mediums.  A legacy
function ``dual_save`` is included for compatibility with existing
backup workflows.

Functions
---------

save_all(data, json_path=None)
    Persist a practice dict to ``app_pratiche/<id_pratica>/pratica.json``
    and to the SQLite database returned by ``db_core.get_db_path()``.
    Returns a dict describing the operation.

dual_save(pratica_folder, backup_dir, base_id, *, data=None, json_text=None, timestamp=None)
    Create timestamped and backup copies of a practice JSON file.  This
    behaviour mirrors the original ``dual_save`` helper used solely
    for JSON backups and is retained here for completeness.
"""

import os
import json
from pathlib import Path
from typing import Dict, Any, Optional

from db_core import get_db_path, connect, init_db, transaction
import repo_sqlite


def _atomic_write_text(path: Path, text: str) -> None:
    """Write text to the given path atomically.

    A temporary file is written to the same directory and then
    atomically replaced.  Parent directories are created as needed.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
        try:
            f.flush()
            os.fsync(f.fileno())
        except Exception:
            pass
    os.replace(tmp, path)


def save_all(data: Dict[str, Any], json_path: Optional[str] = None) -> Dict[str, str]:
    """Persist the supplied practice both as JSON and in SQLite.

    The practice must either define an explicit ``id_pratica`` key or
    provide ``anno`` and ``numero`` fields from which a default
    identifier can be constructed.  When ``json_path`` is omitted,
    JSON is written to ``app_pratiche/<id_pratica>/pratica.json``.

    Parameters
    ----------
    data : dict
        The practice data to persist.
    json_path : str, optional
        Override the location of the JSON file.  If provided, this
        location is used verbatim.

    Returns
    -------
    dict
        A dictionary containing ``json_path``, ``sqlite_path`` and
        ``id_pratica``.

    Raises
    ------
    ValueError
        If the identifier for the practice cannot be determined.
    TypeError
        If ``data`` is not a dictionary.
    Exception
        Propagated from underlying IO or database operations.
    """
    if not isinstance(data, dict):
        raise TypeError("save_all: 'data' must be a dict")
    # Determine id_pratica
    pid = data.get("id_pratica")
    if not pid:
        anno = data.get("anno")
        numero = data.get("numero")
        if anno is None or numero is None:
            raise ValueError("save_all: missing id_pratica and anno/numero")
        pid = f"{anno}-{str(numero).zfill(6)}"
        data["id_pratica"] = pid

    # Determine JSON path
    if json_path is None:
        json_path = os.path.join("app_pratiche", pid, "pratica.json")
    json_file = Path(str(json_path))

    # Serialise and write JSON atomically
    text = json.dumps(data, ensure_ascii=False, indent=2)
    _atomic_write_text(json_file, text)

    # Ensure the database exists and the schema is applied
    db_path = get_db_path()
    init_db(db_path)
    conn = connect(db_path)
    try:
        with transaction(conn):
            repo_sqlite.upsert_pratica(conn, data)
    finally:
        conn.close()
    return {"json_path": str(json_file), "sqlite_path": db_path, "id_pratica": pid}


def dual_save(pratica_folder: Path | str,
              backup_dir: Path | str,
              base_id: str,
              *,
              data: Optional[Dict[str, Any]] = None,
              json_text: Optional[str] = None,
              timestamp: Optional[str] = None) -> Dict[str, str]:
    """Legacy helper to create timestamped and backup copies of JSON.

    This function reproduces the behaviour of the original ``dual_save``
    helper used in the 0GP project, which created two JSON copies: one
    timestamped and one rotating backup.  It does not interact with
    the SQLite backend and is preserved here for backward
    compatibility.

    Parameters
    ----------
    pratica_folder : path
        Folder in which the timestamped file will be written.
    backup_dir : path
        Directory for the rotating backup file.
    base_id : str
        Identifier used to construct the filenames.
    data : dict, optional
        Practice data to serialise.  If ``None``, ``json_text`` or an
        existing ``pratica.json`` will be used.
    json_text : str, optional
        Raw JSON text to write.  If provided, this takes precedence
        over reading from disk.
    timestamp : str, optional
        Timestamp string used in the filename.  If omitted, the
        current date and time will be used.

    Returns
    -------
    dict
        A dictionary containing the paths written, byte count and
        source description.
    """
    pratica_folder = Path(pratica_folder)
    backup_dir = Path(backup_dir)
    base_id = str(base_id)
    if not base_id:
        raise ValueError("dual_save: 'base_id' cannot be empty")

    if data is not None:
        js = json.dumps(data, ensure_ascii=False, indent=2)
        source = "data"
    elif json_text is not None:
        js = str(json_text)
        source = "json_text"
    else:
        canon = pratica_folder / "pratica.json"
        if not canon.exists():
            raise FileNotFoundError(f"dual_save: source {canon} not found; pass 'data' or 'json_text'")
        js = canon.read_text(encoding="utf-8")
        source = "pratica.json"

    from datetime import datetime as _dt
    ts = timestamp or _dt.now().strftime("%d%m%Y_%H%M%S")
    ts_name = f"{base_id}_gp_{ts}.json"
    ts_path = pratica_folder / ts_name
    backup_path = backup_dir / f"{base_id}_gp.json"

    _atomic_write_text(ts_path, js)
    _atomic_write_text(backup_path, js)

    return {
        "timestamped_path": str(ts_path),
        "backup_path": str(backup_path),
        "bytes": str(len(js.encode('utf-8'))),
        "source": source,
    }