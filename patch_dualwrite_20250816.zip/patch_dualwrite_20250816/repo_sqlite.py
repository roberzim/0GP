from __future__ import annotations

"""
repo_sqlite.py
----------------

High‑level helper functions to persist practice data into a SQLite
database.  This module is designed to be lightweight and to operate
against the minimal schema defined in ``db_schema.sql``.  Each
function accepts an existing database connection; if you wish to use
the convenience functions to open a connection automatically, see
``db_core.connect`` and ``db_core.transaction``.

The primary public function is :func:`upsert_pratica`, which inserts
or updates a single practice and then replaces any existing
deadline/document children with the supplied lists.  A helper
function :func:`next_id` is provided to obtain an atomically
incremented counter for a given year.
"""

import json
from typing import Any, Dict, List
from db_core import connect, transaction, get_db_path, init_db


def _to_id_pratica(anno: int, numero: int) -> str:
    """Format the natural identifier for a practice from year and number.

    The number is zero‑padded to six digits for uniform sorting.
    """
    return f"{anno}-{str(numero).zfill(6)}"


def upsert_pratica(conn, pratica_dict: Dict[str, Any]) -> None:
    """Insert or update a practice and its children in the database.

    Parameters
    ----------
    conn : sqlite3.Connection
        A valid SQLite connection open on the target database.
    pratica_dict : dict
        The practice data, including optional ``scadenze`` and
        ``documenti`` lists.  If ``id_pratica`` is absent it will
        be derived from ``anno`` and ``numero``.

    Notes
    -----
    This function uses an ``INSERT ... ON CONFLICT(id_pratica)``
    statement to perform an upsert on the ``pratiche`` table.  It
    delegates replacement of child rows to :func:`upsert_scadenze` and
    :func:`upsert_documenti`.
    """
    if not isinstance(pratica_dict, dict):
        raise TypeError("upsert_pratica: pratica_dict must be a dict")

    # Determine identifier
    pid = pratica_dict.get("id_pratica")
    anno = pratica_dict.get("anno")
    numero = pratica_dict.get("numero")
    if not pid:
        if anno is None or numero is None:
            raise ValueError("upsert_pratica: missing id_pratica and anno/numero")
        pid = _to_id_pratica(int(anno), int(numero))
        pratica_dict["id_pratica"] = pid

    # Serialise the entire practice as JSON for round‑trip integrity
    raw_json = json.dumps(pratica_dict, ensure_ascii=False)

    # Upsert master record
    cols = [
        "id_pratica",
        "anno",
        "numero",
        "titolo",
        "stato",
        "created_at",
        "updated_at",
        "raw_json",
    ]
    values = [
        pid,
        pratica_dict.get("anno"),
        pratica_dict.get("numero"),
        pratica_dict.get("titolo"),
        pratica_dict.get("stato"),
        pratica_dict.get("created_at"),
        pratica_dict.get("updated_at"),
        raw_json,
    ]
    placeholders = ",".join("?" for _ in cols)
    set_list = ",".join([f"{c}=excluded.{c}" for c in cols[1:]])
    conn.execute(
        f"""
        INSERT INTO pratiche ({', '.join(cols)}) VALUES ({placeholders})
        ON CONFLICT(id_pratica) DO UPDATE SET {set_list}
        """,
        values,
    )

    # Replace child rows
    upsert_scadenze(conn, pid, pratica_dict.get("scadenze") or [])
    upsert_documenti(conn, pid, pratica_dict.get("documenti") or [])


def upsert_scadenze(conn, id_pratica: str, scadenze_list: List[Dict[str, Any]]) -> None:
    """Replace all deadlines for the given practice.

    Any existing ``scadenze`` rows for ``id_pratica`` are deleted and
    then reinserted from ``scadenze_list``.  Each item in the list may
    contain ``data`` (or ``data_scadenza``), ``descrizione`` and
    ``stato`` keys; missing keys are stored as ``NULL`` in the
    database.
    """
    conn.execute("DELETE FROM scadenze WHERE id_pratica=?", (id_pratica,))
    for sc in scadenze_list:
        conn.execute(
            "INSERT INTO scadenze(id_pratica, data, descrizione, stato) VALUES (?,?,?,?)",
            (
                id_pratica,
                sc.get("data") or sc.get("data_scadenza"),
                sc.get("descrizione"),
                sc.get("stato"),
            ),
        )


def upsert_documenti(conn, id_pratica: str, docs_list: List[Dict[str, Any]]) -> None:
    """Replace all documents for the given practice.

    Deletes any existing ``documenti`` rows for ``id_pratica`` and
    inserts each document in ``docs_list``.  Accepted keys on each
    document are ``nome``, ``path`` and ``tipo``.
    """
    conn.execute("DELETE FROM documenti WHERE id_pratica=?", (id_pratica,))
    for doc in docs_list:
        conn.execute(
            "INSERT INTO documenti(id_pratica, nome, path, tipo) VALUES (?,?,?,?)",
            (
                id_pratica,
                doc.get("nome"),
                doc.get("path"),
                doc.get("tipo"),
            ),
        )


def next_id(conn, anno: int) -> int:
    """Return the next sequential identifier for a given year.

    If no row exists in ``id_counter`` for the supplied ``anno`` a
    new row is created with ``last_n = 1``.  Otherwise the existing
    counter is incremented and returned.  This operation should be
    invoked within a surrounding transaction to ensure atomicity.
    """
    cur = conn.execute("SELECT last_n FROM id_counter WHERE anno=?", (anno,))
    row = cur.fetchone()
    if row:
        last_n = row["last_n"] + 1
        conn.execute("UPDATE id_counter SET last_n=? WHERE anno=?", (last_n, anno))
    else:
        last_n = 1
        conn.execute("INSERT INTO id_counter(anno, last_n) VALUES(?,?)", (anno, last_n))
    return last_n